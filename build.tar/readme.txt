This High Availability Containerized Application is created and developed by Adeleine Melendrez, Cecilia Merion, Micaela Predestin, and Megan Ruiz for the final project in the System Administration using UNIX (COP3604) course at Florida Polytechnic University.
This project aims to create a web-based application featuring database functionality and container usage on Google Cloud Platform.
